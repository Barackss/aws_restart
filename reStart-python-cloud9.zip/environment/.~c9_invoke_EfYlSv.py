userReply = input("Do you need to ship a package? (Enter yes or no) ")
if userReply == "yes":
    print("We can halp you ship that package")
e    
else:
    print("Please come back when you need to ship a package. Thank you.")
