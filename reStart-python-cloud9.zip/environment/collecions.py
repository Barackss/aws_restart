myfruitlist = ["apple", "banana", "cherry"]
print(myfruitlist)
print(type(myfruitlist))
print(myfruitlist[0])
print(myfruitlist[1])
print(myfruitlist[2])
myfruitlist[2] = "orange"
print(myfruitlist)
myfinalanswerTuple = ("apple", "banana", "pineapple")
print(myfinalanswerTuple)
print(type(myfinalanswerTuple))
print(myfinalanswerTuple[0])
print(myfinalanswerTuple[1])
print(myfinalanswerTuple[2])
myfavoritefruitDictionary = {
    "Akua" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pineapple"
    
}
print(myfavoritefruitDictionary)
print(type(myfavoritefruitDictionary))
print(myfavoritefruitDictionary["Akua"])
print(myfavoritefruitDictionary["Saanvi"])
print(myfavoritefruitDictionary["Paulo"])